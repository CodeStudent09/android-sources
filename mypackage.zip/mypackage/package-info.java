/**
 * The classes in the package are used by {@link libcore.java.nio.file.FileSystemsTest
 * FileSystemsTest}. The tests creates a custom classloader which loads these classes.
 */
package mypackage;